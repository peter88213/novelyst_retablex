"""A csv relationship table export plugin for novelyst

Requires Python 3.6+
Copyright (c) 2022 Peter Triesberger
For further information see https://github.com/peter88213/novelyst_retablex
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import sys
import os
import gettext
import locale
from pathlib import Path
import webbrowser
import tkinter as tk

__all__ = ['Error',
           '_',
           'LOCALE_PATH',
           'CURRENT_LANGUAGE',
           'norm_path',
           'string_to_list',
           'list_to_string',
           ]


class Error(Exception):
    pass


LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('pywriter', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message


def norm_path(path):
    if path is None:
        path = ''
    return os.path.normpath(path)


def string_to_list(text, divider=';'):
    elements = []
    try:
        tempList = text.split(divider)
        for element in tempList:
            element = element.strip()
            if element and not element in elements:
                elements.append(element)
        return elements

    except:
        return []


def list_to_string(elements, divider=';'):
    try:
        text = divider.join(elements)
        return text

    except:
        return ''

from abc import ABC, abstractmethod


class FileFactory(ABC):

    def __init__(self, fileClasses=[]):
        self._fileClasses = fileClasses

    @abstractmethod
    def make_file_objects(self, sourcePath, **kwargs):
        pass


class ExportTargetFactory(FileFactory):

    def make_file_objects(self, sourcePath, **kwargs):
        fileName, __ = os.path.splitext(sourcePath)
        suffix = kwargs['suffix']
        for fileClass in self._fileClasses:
            if fileClass.SUFFIX == suffix:
                if suffix is None:
                    suffix = ''
                targetFile = fileClass(f'{fileName}{suffix}{fileClass.EXTENSION}', **kwargs)
                return None, targetFile

        raise Error(f'{_("Export type is not supported")}: "{suffix}".')
from configparser import ConfigParser


class Configuration:

    def __init__(self, settings={}, options={}):
        self.settings = None
        self.options = None
        self._sLabel = 'SETTINGS'
        self._oLabel = 'OPTIONS'
        self.set(settings, options)

    def read(self, iniFile):
        config = ConfigParser()
        config.read(iniFile, encoding='utf-8')
        if config.has_section(self._sLabel):
            section = config[self._sLabel]
            for setting in self.settings:
                fallback = self.settings[setting]
                self.settings[setting] = section.get(setting, fallback)
        if config.has_section(self._oLabel):
            section = config[self._oLabel]
            for option in self.options:
                fallback = self.options[option]
                self.options[option] = section.getboolean(option, fallback)

    def set(self, settings=None, options=None):
        if settings is not None:
            self.settings = settings.copy()
        if options is not None:
            self.options = options.copy()

    def write(self, iniFile):
        config = ConfigParser()
        if self.settings:
            config.add_section(self._sLabel)
            for settingId in self.settings:
                config.set(self._sLabel, settingId, str(self.settings[settingId]))
        if self.options:
            config.add_section(self._oLabel)
            for settingId in self.options:
                if self.options[settingId]:
                    config.set(self._oLabel, settingId, 'Yes')
                else:
                    config.set(self._oLabel, settingId, 'No')
        with open(iniFile, 'w', encoding='utf-8') as f:
            config.write(f)
import csv


class CsvTable:
    DESCRIPTION = _('csv Table')
    EXTENSION = '.csv'
    SUFFIX = '_relationships'

    def __init__(self, filePath, **kwargs):
        self.novel = None
        self._filePath = None

        self.filePath = filePath
        self._csvArcTrue = kwargs.get('csv_arc_true', 'A')
        self._csvArcFalse = kwargs.get('csv_arc_false', '')
        self._csvChrTrue = kwargs.get('csv_chr_true', 'C')
        self._csvChrFalse = kwargs.get('csv_chr_false', '')
        self._csvLocTrue = kwargs.get('csv_loc_true', 'L')
        self._csvLocFalse = kwargs.get('csv_loc_false', '')
        self._csvItmTrue = kwargs.get('csv_itm_true', 'I')
        self._csvItmFalse = kwargs.get('csv_itm_false', '')
        self._csvRowNumbers = kwargs.get('csv_row_numbers', True)
        self._csvDialect = kwargs.get('csv_dialect', 'ecxel')
        self._csvEncoding = kwargs.get('csv_encoding', 'utf-8')
        self._csv_arcPoints = kwargs.get('csv_arc_points', False)

    @property
    def filePath(self):
        return self._filePath

    @filePath.setter
    def filePath(self, filePath):
        if self.SUFFIX is not None:
            suffix = self.SUFFIX
        else:
            suffix = ''
        if filePath.lower().endswith(f'{suffix}{self.EXTENSION}'.lower()):
            self._filePath = filePath

    def write(self):
        try:
            with open(self.filePath, 'w', newline='', encoding=self._csvEncoding) as f:
                writer = csv.writer(f, dialect=self._csvDialect)

                hasSubplot = False
                arcs = []
                scnArcs = {}
                for chId in self.novel.srtChapters:
                    for scId in self.novel.chapters[chId].srtScenes:
                        if self.novel.scenes[scId].scType == 0:
                            scnArcs[scId] = string_to_list(self.novel.scenes[scId].scnArcs)
                            for arc in scnArcs[scId]:
                                if not arc in arcs:
                                    arcs.append(arc)
                            if self.novel.scenes[scId].isSubPlot:
                                hasSubplot = True

                if hasSubplot and not arcs:
                    arcs.append('Subplot')
                    for scId in scnArcs:
                        if self.novel.scenes[scId].isSubPlot:
                            scnArcs[scId] = ['Subplot']

                row = []
                if self._csvRowNumbers:
                    row.append('')
                row.append('')
                for arc in arcs:
                    row.append(arc)
                for crId in self.novel.characters:
                    row.append(self.novel.characters[crId].title)
                for lcId in self.novel.locations:
                    row.append(self.novel.locations[lcId].title)
                for itId in self.novel.items:
                    row.append(self.novel.items[itId].title)
                writer.writerow(row)

                for i, scId in enumerate(scnArcs):
                    row = []
                    if self._csvRowNumbers:
                        row.append(i + 1)
                    row.append(self.novel.scenes[scId].title)
                    for arc in arcs:
                        if arc in scnArcs[scId]:
                            entry = self._csvArcTrue
                            if self._csv_arcPoints:
                                pointIds = string_to_list(self.novel.scenes[scId].kwVar.get('Field_SceneAssoc', None))
                                points = []
                                for ptId in pointIds:
                                    if arc in self.novel.scenes[ptId].scnArcs:
                                        points.append(self.novel.scenes[ptId].title)
                                if points:
                                    entry = list_to_string(points)
                            row.append(entry)
                        else:
                            row.append(self._csvArcFalse)
                    for crId in self.novel.srtCharacters:
                        try:
                            if crId in self.novel.scenes[scId].characters:
                                row.append(self._csvChrTrue)
                            else:
                                row.append(self._csvChrFalse)
                        except:
                            row.append(self._csvChrFalse)
                    for lcId in self.novel.srtLocations:
                        try:
                            if lcId in self.novel.scenes[scId].locations:
                                row.append(self._csvLocTrue)
                            else:
                                row.append(self._csvLocFalse)
                        except:
                            row.append(self._csvLocFalse)
                    for itId in self.novel.srtItems:
                        try:
                            if itId in self.novel.scenes[scId].items:
                                row.append(self._csvItmTrue)
                            else:
                                row.append(self._csvItmFalse)
                        except:
                            row.append(self._csvItmFalse)
                    writer.writerow(row)
        except:
            raise Error(f'{_("Cannot write File")}: "{norm_path(self.filePath)}".')

        return (f'{_("File written")}: "{norm_path(self.filePath)}".')


def open_document(document):
    try:
        os.startfile(norm_path(document))
    except:
        try:
            os.system('xdg-open "%s"' % norm_path(document))
        except:
            try:
                os.system('open "%s"' % norm_path(document))
            except:
                pass

SETTINGS = dict(
    csv_arc_true='Ⓐ',
    csv_arc_false='',
    csv_chr_true='Ⓒ',
    csv_chr_false='',
    csv_loc_true='Ⓛ',
    csv_loc_false='',
    csv_itm_true='Ⓘ',
    csv_itm_false='',
    )
OPTIONS = dict(
    csv_row_numbers=True,
    csv_arc_points=True,
    show_exported=True,
    )

LOCALE_PATH = f'{os.path.dirname(sys.argv[0])}/locale/'
try:
    CURRENT_LANGUAGE = locale.getlocale()[0][:2]
except:
    CURRENT_LANGUAGE = locale.getdefaultlocale()[0][:2]
try:
    t = gettext.translation('novelyst_retablex', LOCALE_PATH, languages=[CURRENT_LANGUAGE])
    _ = t.gettext
except:

    def _(message):
        return message

APPLICATION = _('Relationship table export')
PLUGIN = f'{APPLICATION} plugin v1.1.0'


class Plugin:
    """novelyst relationship table export plugin class.
    
    Public methods:
        on_quit() -- Apply changes and close the window.
    """
    VERSION = '1.1.0'
    NOVELYST_API = '4.0'
    DESCRIPTION = 'A relationship table exporter'
    URL = 'https://peter88213.github.io/novelyst_retablex'
    _HELP_URL = 'https://peter88213.github.io/novelyst_retablex/usage'

    def install(self, ui):
        """Add a "Relationship table export" submenu to the 'Export' menu.
        
        Positional arguments:
            ui -- reference to the NovelystTk instance of the application.
        """
        self._ui = ui
        self._csvExporter = None

        try:
            homeDir = str(Path.home()).replace('\\', '/')
            configDir = f'{homeDir}/.pywriter/novelyst/config'
        except:
            configDir = '.'
        self.iniFile = f'{configDir}/retable.ini'
        self.configuration = Configuration(SETTINGS, OPTIONS)
        self.configuration.read(self.iniFile)
        self.kwargs = {}
        self.kwargs.update(self.configuration.settings)
        self.kwargs.update(self.configuration.options)

        retablexMenu = tk.Menu(tearoff=0)
        self._ui.exportMenu.add_separator()
        self._ui.exportMenu.add_cascade(label=APPLICATION, menu=retablexMenu)
        self._ui.exportMenu.entryconfig(APPLICATION, state='normal')
        retablexMenu.add_command(label='csv', command=lambda: self._export_table('excel', 'utf-8'))
        retablexMenu.add_command(label='csv (Excel)', command=lambda:self._export_table('excel-tab', 'utf-16'))

        self._ui.helpMenu.add_command(label=_('Relationship table export plugin Online Help'), command=lambda: webbrowser.open(self._HELP_URL))

    def _export_table(self, csvDialect, csvEncoding):
        exportTargetFactory = ExportTargetFactory([CsvTable])
        try:
            self.kwargs['suffix'] = CsvTable.SUFFIX
            self.kwargs['csv_dialect'] = csvDialect
            self.kwargs['csv_encoding'] = csvEncoding
            __, target = exportTargetFactory.make_file_objects(self._ui.prjFile.filePath, **self.kwargs)
        except Exception as ex:
            self._ui.set_info_how(f'!{str(ex)}')
            return

        self._ui.refresh_tree()
        target.novel = self._ui.novel
        try:
            message = target.write()
        except Exception as ex:
            self._ui.set_info_how(f'!{str(ex)}')
        else:
            self._ui.set_info_how(message)
            if self.kwargs['show_exported']:
                if self._ui.ask_yes_no(_('Document "{}" created. Open now?').format(norm_path(target.filePath))):
                    open_document(target.filePath)

    def on_quit(self):
        """Actions to be performed when novelyst is closed.
        
        Save the project specific configuration
        """
        for keyword in self.kwargs:
            if keyword in self.configuration.options:
                self.configuration.options[keyword] = self.kwargs[keyword]
            elif keyword in self.configuration.settings:
                self.configuration.settings[keyword] = self.kwargs[keyword]
        self.configuration.write(self.iniFile)

